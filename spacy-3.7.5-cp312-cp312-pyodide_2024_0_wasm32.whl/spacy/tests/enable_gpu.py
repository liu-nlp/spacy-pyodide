from spacy import require_gpu

require_gpu()
