"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.hu.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "Az Apple egy brit startup vásárlását tervezi 1 milliárd dollár értékben.",
    "San Francisco vezetése mérlegeli a járdát használó szállító robotok betiltását.",
    "London az Egyesült Királyság egy nagy városa.",
]
